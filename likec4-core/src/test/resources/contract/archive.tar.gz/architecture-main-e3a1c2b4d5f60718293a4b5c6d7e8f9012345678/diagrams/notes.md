# scratch notes, not a diagram
