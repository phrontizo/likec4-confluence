# Architecture
This repo holds the LikeC4 model. (Not a LikeC4 file — must be filtered out.)
