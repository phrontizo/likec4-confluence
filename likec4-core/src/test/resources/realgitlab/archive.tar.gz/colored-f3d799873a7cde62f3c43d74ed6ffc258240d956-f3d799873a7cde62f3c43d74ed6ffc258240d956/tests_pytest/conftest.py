import pytest


@pytest.fixture(autouse=True)
def force_color(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv('FORCE_COLOR', '1')
