from colored.attributes import Style
from colored.colored import Colored
from colored.library import Library

ESC: str = '\x1b['
END: str = 'm'
UNDERLINE_COLOR: str = f'{ESC}4;58;5;'


def test_style_code() -> None:
    for code in Library.STYLES.values():
        style = Colored(code)
        assert f'{ESC}{code}{END}' == style.attribute()


def test_style_name() -> None:
    for name, code in Library.STYLES.items():
        style = Colored(name)
        assert f'{ESC}{code}{END}' == style.attribute()


def test_underline_color() -> None:
    for code in Library.COLORS.values():
        assert f'{UNDERLINE_COLOR}{code}{END}' == Style.underline_color(color=code)
