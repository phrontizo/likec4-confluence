from colored.colored import Colored, fore, fore_rgb
from colored.foreground import Fore
from colored.library import Library

ESC: str = '\x1b['
FOREGROUND_256: str = f'{ESC}38;5;'
FOREGROUND_RGB: str = f'{ESC}38;2;'
END: str = 'm'


def test_foreground_256_code() -> None:
    for code in Library.COLORS.values():
        color = Colored(code)
        assert f'{FOREGROUND_256}{code}{END}' == color.foreground()


def test_foreground_256_name() -> None:
    for name, code in Library.COLORS.items():
        color = Colored(name)
        assert f'{FOREGROUND_256}{code}{END}' == color.foreground()


def test_fore_256_func() -> None:
    for name, code in Library.COLORS.items():
        color = Colored(name)
        assert fore(code) == color.foreground()


def test_foreground_rgb() -> None:
    for code in Library.COLORS.values():
        assert f'{FOREGROUND_RGB}{code};{code};{code}{END}' == Fore.rgb(code, code, code)


def test_foreground_rgb_func() -> None:
    for code in Library.COLORS.values():
        assert f'{FOREGROUND_RGB}{code};{code};{code}{END}' == fore_rgb(code, code, code)
