import pytest

from colored.exceptions import InvalidColor, InvalidControl, InvalidHexColor, InvalidStyle


def test_exception_raised_invalidcolor() -> None:
    with pytest.raises(InvalidColor) as ctx:
        raise InvalidColor("InvalidColor: red_90")
    assert str(ctx.value) == "InvalidColor: red_90"


def test_exception_message_invalidcolor() -> None:
    assert str(InvalidColor("InvalidColor: red_90")) == "InvalidColor: red_90"


def test_exception_inheritance_invalidcolor() -> None:
    assert isinstance(InvalidColor("Test"), Exception)


def test_exception_raised_invalidhexcolor() -> None:
    with pytest.raises(InvalidHexColor) as ctx:
        raise InvalidHexColor("InvalidHexColor: #005fdj")
    assert str(ctx.value) == "InvalidHexColor: #005fdj"


def test_exception_message_invalidhexcolor() -> None:
    assert str(InvalidHexColor("InvalidHexColor: blue_15")) == "InvalidHexColor: blue_15"


def test_exception_inheritance_invalidhexcolor() -> None:
    assert isinstance(InvalidHexColor("Test"), Exception)


def test_exception_raised_invalidcontrol() -> None:
    with pytest.raises(InvalidControl) as ctx:
        raise InvalidControl("InvalidControl: upper")
    assert str(ctx.value) == "InvalidControl: upper"


def test_exception_message_invalidcontrol() -> None:
    assert str(InvalidControl("InvalidControl: righting")) == "InvalidControl: righting"


def test_exception_inheritance_invalidcontrol() -> None:
    assert isinstance(InvalidControl("Test"), Exception)


def test_exception_raised_invalidstyle() -> None:
    with pytest.raises(InvalidStyle) as ctx:
        raise InvalidStyle("InvalidStyle: bolb")
    assert str(ctx.value) == "InvalidStyle: bolb"


def test_exception_message_invalidstyle() -> None:
    assert str(InvalidStyle("InvalidStyle: bolb")) == "InvalidStyle: bolb"


def test_exception_inheritance_invalidstyle() -> None:
    assert isinstance(InvalidStyle("Test"), Exception)
