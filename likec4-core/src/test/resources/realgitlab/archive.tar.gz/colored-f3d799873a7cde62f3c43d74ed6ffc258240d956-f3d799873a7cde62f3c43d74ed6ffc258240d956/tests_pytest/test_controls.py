from colored.controls import Controls
from colored.exceptions import InvalidControl


ESC: str = '\x1b['


def test_nav_cursor_down() -> None:
    assert Controls().nav('down', 3) == f'{ESC}3B'


def test_nav_cursor_up() -> None:
    assert Controls().nav('up', 2) == f'{ESC}2A'


def test_nav_position() -> None:
    assert Controls().nav('position', 5, 10) == f'{ESC}5;10H'


def test_nav_position_column_zero() -> None:
    assert Controls().nav('position', 5, 0) == f'{ESC}5;0H'


def test_nav_invalid_column_raises() -> None:
    try:
        Controls().nav('down', 3, 5)
    except InvalidControl:
        pass


def test_nav_invalid_name_raises() -> None:
    try:
        Controls().nav('invalid', 1)
    except InvalidControl:
        pass
