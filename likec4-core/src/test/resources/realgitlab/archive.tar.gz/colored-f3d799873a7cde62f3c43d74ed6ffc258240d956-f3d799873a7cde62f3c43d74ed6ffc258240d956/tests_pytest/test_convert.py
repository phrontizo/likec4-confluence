from colored.convert import Convert
from colored.library import Library


def test_hex_to_ansi() -> None:
    convert = Convert()
    for hex_code in Library.HEX_COLORS.values():
        result = convert.hex_to_ansi(hex_code)
        assert result is not None
        # Result is an ANSI escape sequence — extract the code number
        ansi_num = result.replace('\x1b[38;5;', '').replace('m', '')
        assert Library.HEX_COLORS.get(ansi_num) == hex_code


def test_ansi_to_hex() -> None:
    convert = Convert()
    for ansi_code, hex_code in Library.HEX_COLORS.items():
        result = convert.ansi_to_hex(int(ansi_code))
        assert result == hex_code


def test_hex_to_ansi_invalid() -> None:
    convert = Convert()
    assert convert.hex_to_ansi('#000000invalid') is None


def test_ansi_to_hex_invalid() -> None:
    convert = Convert()
    assert convert.ansi_to_hex(9999) is None
