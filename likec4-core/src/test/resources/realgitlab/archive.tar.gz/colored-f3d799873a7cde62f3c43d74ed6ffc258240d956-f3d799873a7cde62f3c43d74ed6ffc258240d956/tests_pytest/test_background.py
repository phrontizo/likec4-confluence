from colored.background import Back
from colored.colored import Colored, back, back_rgb
from colored.library import Library

ESC: str = '\x1b['
BACKGROUND_256: str = f'{ESC}48;5;'
BACKGROUND_RGB: str = f'{ESC}48;2;'
END: str = 'm'


def test_background_256_code() -> None:
    for code in Library.COLORS.values():
        color = Colored(code)
        assert f'{BACKGROUND_256}{code}{END}' == color.background()


def test_background_256_name() -> None:
    for name, code in Library.COLORS.items():
        color = Colored(name)
        assert f'{BACKGROUND_256}{code}{END}' == color.background()


def test_back_256_func() -> None:
    for name, code in Library.COLORS.items():
        color = Colored(name)
        assert back(code) == color.background()


def test_background_rgb() -> None:
    for code in Library.COLORS.values():
        assert f'{BACKGROUND_RGB}{code};{code};{code}{END}' == Back.rgb(code, code, code)


def test_background_rgb_func() -> None:
    for code in Library.COLORS.values():
        assert f'{BACKGROUND_RGB}{code};{code};{code}{END}' == back_rgb(code, code, code)
